
var stars = [], carvingPoints = [];
//This only exits to make the first carvingPoints declaration easier
var cPointsLength = 0;
function setup() {
    createCanvas(600,450);
    colorMode(RGB, 255, 255, 255, 1);
    background(0); 

    ellipseMode(RADIUS);
    strokeWeight(0);

    //star creation (star x pos index is odd, y pos even)
    for (var i = 0; i < 450; i+=2) {
        //I know there is a better way to use the random function, im just more used to this
        stars[i] = random() * 300;
        stars[i+1] = random() * 600;
    }

    //Just here for the req
    print(stars.length);
}

function draw()
{
    background(2,4,18);

    //drawing stars
    fill(255, 255, 255, .4);
    for (var i = 0; i < stars.length; i+=2) {
        //Allows for stars to loop  around the screen
        if(stars[i+1] > 600)
            stars[i + 1] = 0;
        ellipse(stars[i+1],stars[i],1.5);

        stars[i+1] += random() * .5;
    }

    ellipseMode(CENTER);

    //drawing ground
    fill(13,61,4, 1);
    ellipse(50,380, 500,175);
    fill(24,94,11, 1);
    ellipse(450,450, 710,300);
    
    //defined below
    drawPumpkin();

    ellipseMode(RADIUS);

    //creating the "carving"
    fill(235,232,52, .6);
    //just creating a rough outline area so that the user doesn't just draw in the sky accidently
    if (mouseX > 140 && mouseX < 460 && mouseY > 140 && mouseY < 400) {
        ellipse(mouseX,mouseY, 3);
        //making sure the user moves to prevent too many of the same data points being added and slowing down the draw
        if (mouseIsPressed && dist(pmouseX,pmouseX, mouseX,mouseY)!=0) {
            //unlike stars even indexes are x values, and odd are y values
            carvingPoints[cPointsLength++] = mouseX;
            carvingPoints[cPointsLength++] = mouseY;
        }
    }
    for (var i = 0; i < carvingPoints.length; i+=2) 
        ellipse(carvingPoints[i], carvingPoints[i+1], 3);
    

}

function drawPumpkin() {
    //this is mostly just here becasue I don't like how long strings of shape calls look

    //stem
    fill(122, 103, 38, 1);
    triangle(280,160, 320,160, 300,90);
    rect(290,90, 22,60);
    //intentionally offset for astetics

    fill(209,137,21,1);
    ellipse(180,270, 75,200);
    ellipse(420,270, 75,200);

    ellipse(205,270, 90,230);
    ellipse(395,270, 90,230);

    ellipse(235,270, 90,245);
    ellipse(365,270, 90,245);

    ellipse(265,270, 100,253);
    ellipse(335,270, 100,253);
    
    ellipse(300,270, 125,255);
}
