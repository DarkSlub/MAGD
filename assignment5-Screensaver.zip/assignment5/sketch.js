//I am going to be re-implementing my previous assignments code
//into this one, as it kinda fits the theme, and so that the buttons
//actually do something
var fr = 30;
var x1=0, x2=0, y1=0, y2=0;
var xVelo = 2, yVelo = 2;
var resetCount = 0;
var lockout = true;
var screenX1 = 60, screenX2 = 480 + screenX1, screenY1 = 46, screenY2 = screenY1 + 258;
function setup() {
    createCanvas(600,450);
    colorMode(RGB, 255, 255, 255, 1);
    background(0); //for postarity

    ellipseMode(RADIUS);

    x1 = random() * (screenX2 - screenX1 - 15) + screenX1;
    y1 = random() * (screenY2 - screenY1 - 15) + screenY1;
    x2 = x1 + 15;
    y2 = y1 + 15;

    //creating the "monitor" in the setup function so the
    //"screen" will be able to update correctly
    strokeWeight(0);
    fill(224,218,101,1);
    rect(0,0,width,height-100);

    fill(143, 139, 66, 1);
    rect(30,30,width-30*2,height-80*2);

    //On button (purely visual)
    fill(35,173,53, 1);
    rect(570,330, 20,20);
    fill(7, 240, 58, .01);
    for (var i = 0; i < 40; i++)
        ellipse(580,340, i,i);

    //"shadow"
    fill(0, 0, 0, .5);
    triangle(-25,height-100, width+25,0, width,height-100);

    //"screen"
    fill(121, 100, 161, 1);
    rect(60, 46, width-120,height-192);

    //background
    fill(89, 84, 97, 1);
    rect(0, height - 100, width, height);
    fill(0, 0, 0, .35);
    rect(0, height - 100, width, height);

    frameRate(fr);
}

function draw()
{
    //"screen"
    fill(121, 100, 161, .4); 
    rect(60, 46, width - 120, height - 192);

    //draws the moving square
    fill(255,255,255, 1);
    rect(x1,y1, 15,15);

    //keyboard
    fill(224, 218, 101, 1);
    rect(155,height-80, width-300, 70);
    fill(0,0,0, .25);
    rect(155, height - 80, width - 300, 70);

    //Keys
    if (mouseX >= 170 && mouseX <= 380 && mouseY >= 380 && mouseY <= 430) {
        fill(133, 83, 224, 1);
        rect(170, 380, 210, 50);
        if (keyIsPressed && key == 'r') {
            fill(0, 0, 0, .25);
            rect(170, 380, 210, 50);

            //Reseting logic
            if (resetCount == 15 && lockout) {
                resetCount = 0;
                lockout = false;
                x1 = random() * (screenX2 - screenX1 - 15) + screenX1;
                y1 = random() * (screenY2 - screenY1 - 15) + screenY1;
                x2 = x1 + 15;
                y2 = y1 + 15;
            }
            else if (!lockout) {
                fill(255,15,15, 1);
                text("Release 'r' to reset again", 209, 423);
            }
            else
                resetCount++;
        }
        else {
            lockout = true;
            resetCount = 0;
        }
    }
    else {
        fill(224, 218, 101, 1);
        rect(170, 380, 210, 50);
        
    }
    fill(255, 255, 255, 1);
    text("Hold 'r' to reset postion", 215, 410);
    

    if (dist(mouseX, mouseY, 417, 405) <= 25) {
        fill(133, 83, 224, 1);
        ellipse(417, 405, 25, 25);
        if (mouseIsPressed) {
            fill(0, 0, 0, .25);
            ellipse(417, 405, 25, 25);

            //speeding up box (also the top speed is lower because the "screen" is smaller)
            if (abs(xVelo) < 50 && frameCount % 2 == 0) {
                if (xVelo > 0)
                    xVelo++;
                else
                    xVelo--;
                if (yVelo > 0)
                    yVelo++;
                else
                    yVelo--;
            }
        }
    }
    else {
        fill(224, 218, 101, 1);
        ellipse(417, 405, 25, 25);

        //slowing down box
        if (abs(xVelo) > 2 && frameCount % 4 == 0) {
            if (xVelo > 0)
                xVelo--;
            else
                xVelo++;
            if (yVelo > 0)
                yVelo--;
            else
                yVelo++;
        }
    }
    fill(255, 255, 255, 1);
    triangle(417,405, 407,415, 407,395);
    triangle(427,405, 417,415, 417,395);

    //bounds checks
    if (x1 + xVelo > screenX1 && x2 + xVelo < screenX2) {
        x1 += xVelo;
        x2 += xVelo;
    }
    else
        xVelo *= -1;

    if (y1 + yVelo > screenY1 && y2 + yVelo < screenY2) {
        y1 += yVelo;
        y2 += yVelo;
    }
    else
        yVelo *= -1;
}
