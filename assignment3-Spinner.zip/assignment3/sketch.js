

let fr = 60, mx = 0, my = 0, px = 0, py = 0, pRad = 0;
let red = 0, blue = 0, gre = 0;

function setup() {
    createCanvas(512, 512);

    background(200);

    //maybe add
    //translate(256, 256);

    frameRate(fr);
}

function draw()
{
    colorMode(RGB, 255, 255, 255, 1);
    mx = mouseX;
    my = mouseY;
    px = pmouseX;
    py = pmouseY;

    //checks if mouse moved
    if (dist(mx, my, px, py) != 0) {
        red = random() * 255;
        blue = random() * 255;
        green = random() * 255;
    }

    //the opacity makes the swap between colors easier on the eyes
    fill(red, green, blue, .4);

    arc(mx, my, abs(sin(radians(frameCount)) * 100 + 60), abs(sin(radians(frameCount)) * 100 + 60), pRad, pRad + radians(8));
    //creates opposite arc
    arc(mx, my, abs(sin(radians(frameCount)) * 100 + 60), abs(sin(radians(frameCount)) * 100 + 60), pRad + radians(180), pRad + radians(188));


    pRad = pRad + radians(8);
}